<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body class="flex mh-100">
<main id="app" role="main" class="container md:px-0 mx-auto flex-shrink-0">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>
<?php /**PATH /Users/ywchang/Documents/laravel/WingChunTube/resources/views/html.blade.php ENDPATH**/ ?>