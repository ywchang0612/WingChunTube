<?php $__env->startSection('content'); ?>
    <div class="mb-4 mt-4 px-4">
        <form>
            <input
                class="border-gray-200 focus:border-gray-500 appearance-none block w-full bg-gray-200 text-gray-700 border rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white"
                type="text"
                name="search"
                placeholder="搜尋"
                value="<?php echo e(request('search')); ?>"
            >
        </form>
    </div>
    <div class="mb-4">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="hover:bg-indigo-500 hover:text-white py-2 px-4">
                    <a href="videos/<?php echo e(base64_encode($video['path'])); ?>"><?php echo e($video['path']); ?></a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($items->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ywchang/Documents/laravel/WingChunTube/resources/views/video/index.blade.php ENDPATH**/ ?>