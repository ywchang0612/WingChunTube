<?php $__env->startSection('content'); ?>
    <div>
        <Player class="w-full h-screen" url="<?php echo e($url); ?>" mime-type="<?php echo e($mimeType); ?>"></Player>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPrepend('script'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPrepend(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        new Vue({
            'el': '#app',
        })
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ywchang/Documents/laravel/WingChunTube/resources/views/video/show.blade.php ENDPATH**/ ?>